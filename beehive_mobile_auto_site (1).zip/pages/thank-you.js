// pages/thank-you.js - placeholder content
